package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/** Doktor listesi / ekleme sayfası */
public class DoctorsPage extends BasePage {

    public DoctorsPage(WebDriver driver) {
        super(driver);
    }

    /** “Doktor Ekle” ya da “Yeni” benzeri butona bas */
    public DoctorsPage startNewDoctor() {
        try { clickByText("Doktor Ekle"); } catch (Exception e) { clickByText("Yeni"); }
        return this;
    }

    /** Form alanlarını doldur */
    public DoctorsPage fillDoctorForm(DoctorData data) {
        // İsim/Ad Soyad
        type(anyInputWithLabel("Ad"), data.fullName());
        type(anyInputWithLabel("Soyad"), data.lastNameFallback());
        // Tek “Ad Soyad” alanı varsa:
        try { type(anyInputWithLabel("Ad Soyad"), data.fullName()); } catch (Exception ignored) {}

        // Departman (select)
        try {
            click(labelledSelect("Departman"));
            click(By.xpath("//*[self::div or self::li][contains(.,'" + data.department() + "')]"));
        } catch (Exception ignored) {}

        // Zorunlu başka alanlar varsa benzer şekilde:
        // type(anyInputWithLabel("TC"), data.identityNo());

        return this;
    }

    /** Kaydet ve başarıyı doğrula */
    public boolean saveAndVerify() {
        // Kaydet / Oluştur / Tamamla vb.
        try { clickByText("Kaydet"); } catch (Exception e) { clickByText("Oluştur"); }

        // Başarı bildirimi – projeye göre değişebilir; esnek kontrol:
        if (pageHasText("başarı") || pageHasText("kaydedildi") || pageHasText("oluşturuldu")) {
            return true;
        }

        // Alternatif: yeni kaydın listede görünmesi
        // (Liste yenilenince ilk satır vb. kontrol edilebilir)
        return false;
    }

    /** Label’ında metin geçen input’u bulur (genel amaçlı) */
    private By anyInputWithLabel(String label) {
        return By.xpath(
                "//*[self::label][contains(.,'" + label + "')]/following::input[1] | " +
                        "//*[@placeholder][contains(.,'" + label + "') or contains(@placeholder,'" + label + "')][1]"
        );
    }

    /** Label’ına göre select/tetikleyici tıklar */
    private By labelledSelect(String label) {
        return By.xpath(
                "//*[self::label][contains(.,'" + label + "')]/following::*" +
                        "[(self::div or self::button or self::span) and (contains(@class,'select') or @role='combobox')][1]"
        );
    }
}
