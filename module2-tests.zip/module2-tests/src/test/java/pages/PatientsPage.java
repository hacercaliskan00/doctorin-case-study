package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/** Hastalar modülü – hasta oluşturma / arama vb. */
public class PatientsPage extends BasePage {

    public PatientsPage(WebDriver driver) {
        super(driver);
    }

    /* ==== Aksiyonlar ==== */

    /** "Yeni Hasta" / "Hasta Oluştur" butonu */
    public PatientsPage startNewPatient() {
        try { clickByText("Yeni Hasta"); } catch (Exception e) { clickByText("Hasta Oluştur"); }
        return this;
    }

    public PatientsPage setFirstName(String name) {
        type(anyInputWithLabel("Ad"), name);
        return this;
    }

    public PatientsPage setLastName(String surname) {
        type(anyInputWithLabel("Soyad"), surname);
        return this;
    }

    public PatientsPage setNationalId(String tc) {
        // TC Kimlik / Kimlik No gibi farklı etiketler olabilir
        try { type(anyInputWithLabel("TC"), tc); }
        catch (Exception e) { type(anyInputWithLabel("Kimlik"), tc); }
        return this;
    }

    public PatientsPage setBirthDate(String yyyyMmDd) {
        try { type(anyInputWithLabel("Doğum"), yyyyMmDd); } catch (Exception ignored) {}
        return this;
    }

    public PatientsPage setPhone(String phone) {
        try { type(anyInputWithLabel("Telefon"), phone); }
        catch (Exception e) { type(anyInputWithLabel("Cep"), phone); }
        return this;
    }

    public PatientsPage selectGender(String genderText) {
        // Cinsiyet alanı select/combobox olabilir
        try {
            click(labelledSelect("Cinsiyet"));
            click(optionByText(genderText));
        } catch (Exception e) {
            // Bazı formlarda radio buton olabilir
            click(By.xpath("//*[self::label or self::span][contains(.,'" + genderText + "')]"));
        }
        return this;
    }

    public boolean saveAndVerify(String expectedName) {
        try { clickByText("Kaydet"); } catch (Exception e) { clickByText("Oluştur"); }
        // Başarı mesajı veya listede hasta adı
        return pageHasText("başarı") || pageHasText("kaydedildi") || pageHasText(expectedName);
    }

    /* ==== Locator yardımcıları (BasePage ile uyumlu) ==== */

    private By anyInputWithLabel(String label) {
        return By.xpath(
                "//*[self::label][contains(.,'" + label + "')]/following::input[1] | " +
                        "//*[@placeholder][contains(@placeholder,'" + label + "')][1]"
        );
    }

    private By labelledSelect(String label) {
        return By.xpath(
                "//*[self::label][contains(.,'" + label + "')]/following::*" +
                        "[(self::div or self::button or self::span) and (contains(@class,'select') or @role='combobox')][1]"
        );
    }

    private By optionByText(String text) {
        return By.xpath("//*[self::div or self::li or self::span][contains(normalize-space(),'" + text + "')]");
    }
}
