package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

public class LoginPage {

    private final WebDriver driver;
    private final WebDriverWait wait;
    private final Duration TIMEOUT = Duration.ofSeconds(15);
    private final Duration POLL = Duration.ofMillis(250);

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, TIMEOUT, POLL.toMillis());
    }

    // ---------- LOCATORS ----------

    // “değiştir” butonu (tenant seçimi)
    private final By changeTenantBtn =
            By.xpath("//button[.//text()[contains(.,'değiştir')]] | //a[.//text()[contains(.,'değiştir')]]");

    // Tenant arama input’u (modal/pencere içinde oluyor)
    private final List<By> tenantSearchInputs = Arrays.asList(
            By.cssSelector("input[type='search']"),
            By.cssSelector("input[placeholder*='Ara' i]"),
            By.xpath("//input[contains(@placeholder,'Ara') or contains(@aria-label,'Ara')]")
    );

    // Tenant listesinde satır (metne göre tıklayacağız)
    private By tenantRow(String name) {
        return By.xpath("//*[self::div or self::li or self::a]" +
                "[contains(normalize-space(.),'" + name + "')]");
    }

    // Kullanıcı adı alanı için olası locator’lar
    private final List<By> usernameInputs = Arrays.asList(
            By.cssSelector("input[name='username']"),
            By.cssSelector("input#username"),
            By.cssSelector("input[autocomplete='username']"),
            By.xpath("//input[@type='email' or @name='Username' or " +
                    "contains(@placeholder,'Kullanıcı') or contains(@aria-label,'Kullanıcı')]")
    );

    // Şifre alanı için olası locator’lar
    private final List<By> passwordInputs = Arrays.asList(
            By.cssSelector("input[type='password']"),
            By.cssSelector("input[name='password']"),
            By.cssSelector("input#password"),
            By.xpath("//input[@type='password' or @name='Password' or " +
                    "contains(@placeholder,'Şifre') or contains(@aria-label,'Şifre')]")
    );

    // “Giriş” butonu
    private final By loginButton =
            By.xpath("//button[@type='submit' or contains(.,'Giriş') or .//span[contains(.,'Giriş')]]");

    // Dashboard’da olduğumuzu gösteren basit bir belirti (menü ya da url)
    private final By anyDashboardClue =
            By.xpath("//*[contains(@class,'sidebar') or contains(@class,'menu') or contains(.,'Randevu')]");

    // ---------- PUBLIC FLOW ----------

    /** Giriş akışı: tenant seç + kullanıcı adı + şifre + giriş */
    public void loginAs(String user, String pass) {
        ensureTenantSelectedIfNeeded("Nişantaşı Klinik");   // İstersen testi parametreleştirirsin
        WebElement u = findFirstEnabledVisible(usernameInputs);
        WebElement p = findFirstEnabledVisible(passwordInputs);

        safeClearAndType(u, user);
        safeClearAndType(p, pass);

        wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
    }

    /** Eğer müşteri seçilmemişse “değiştir” ile seç. Seçilmişse dokunma. */
    public void ensureTenantSelectedIfNeeded(String tenantName) {
        // Sayfada “MÜŞTERİ – Seçili değil” görünüyorsa buton çalışır durumda oluyor.
        List<WebElement> changeButtons = driver.findElements(changeTenantBtn);
        if (!changeButtons.isEmpty()) {
            // Genel yaklaşım: her zaman açık şekilde butonu dene, modalı getir.
            try {
                WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(changeTenantBtn));
                btn.click();

                WebElement search = findFirstEnabledVisible(tenantSearchInputs);
                safeClearAndType(search, tenantName);

                // Listeden adı geçen ilk satıra tıkla
                WebElement row = wait.until(ExpectedConditions
                        .elementToBeClickable(tenantRow(tenantName)));
                row.click();

                // Seçim sonrası kullanıcı adı input’u aktif hale gelmeli – onu bekleyelim
                findFirstEnabledVisible(usernameInputs);
            } catch (TimeoutException ignored) {
                // Buton yoksa veya zaten seçiliyse devam
            }
        }
    }

    /** Login sonrası dashboard göründü mü? */
    public boolean isDashboardVisible() {
        try {
            wait.until((ExpectedCondition<Boolean>) d ->
                    d.getCurrentUrl().toLowerCase().contains("dashboard")
                            || !driver.findElements(anyDashboardClue).isEmpty());
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }

    // ---------- HELPERS ----------

    /** Verilen locator listesinden ilk görünür ve tıklanabilir WebElement’i döndürür. */
    private WebElement findFirstEnabledVisible(List<By> candidates) {
        TimeoutException last = null;
        for (By by : candidates) {
            try {
                WebElement el = wait.until(ExpectedConditions.presenceOfElementLocated(by));
                wait.until(ExpectedConditions.visibilityOf(el));
                wait.until(ExpectedConditions.elementToBeClickable(el));
                // disabled olup olmadığını da kontrol et
                if (el.isEnabled()) return el;
            } catch (TimeoutException e) {
                last = e;
            }
        }
        throw new TimeoutException("Görünür/etkin input bulunamadı.", last);
    }

    /** Bazı alanlar doğrudan clear kabul etmeyebiliyor – güvenli doldur. */
    private void safeClearAndType(WebElement e, String text) {
        try {
            e.click();
            e.clear();
        } catch (InvalidElementStateException ignored) {
            // Bazı input’lar clear desteklemeyebilir; sadece yazacağız
        }
        e.sendKeys(text);
    }
}
