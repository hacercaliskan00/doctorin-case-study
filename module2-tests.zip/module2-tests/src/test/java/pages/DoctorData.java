package pages;

/** Doktor oluşturma verisi */
public record DoctorData(String fullName, String department) {

    /** Soyad alanı ayrıysa boş kalmasın diye basit bir fallback */
    public String lastNameFallback() {
        String[] parts = fullName.trim().split("\\s+");
        return parts.length > 1 ? parts[parts.length - 1] : fullName;
    }

    public static DoctorData sample() {
        return new DoctorData("Dr. Ayşe Yılmaz", "Dahiliye");
    }
}
