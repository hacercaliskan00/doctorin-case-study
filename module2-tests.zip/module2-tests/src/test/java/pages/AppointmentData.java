package pages;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public record AppointmentData(String doctor, String patient, String department,
                              String date, String time, String note) {

    public static AppointmentData sample(String doctor, String patient, String department) {
        // Bugünden 1 gün sonrası, 10:30 örnek
        String dt = LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
        String tm = LocalTime.of(10, 30).format(DateTimeFormatter.ofPattern("HH:mm"));
        return new AppointmentData(doctor, patient, department, dt, tm, "Otomasyon notu");
    }
}
