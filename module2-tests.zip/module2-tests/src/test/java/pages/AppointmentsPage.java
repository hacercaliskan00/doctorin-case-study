package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Randevu listesi / oluşturma / durum güncelleme sayfası.
 * Buradaki aksiyonlar testlerde doğrudan kullanılacak şekilde sarmalanmıştır.
 */
public class AppointmentsPage extends BasePage {

    public AppointmentsPage(WebDriver driver) {
        super(driver);
    }

    /* ================== OLUŞTURMA ================== */

    /** “Randevu Oluştur” / “Yeni Randevu” butonuna bas */
    public AppointmentsPage startNewAppointment() {
        try {
            clickByText("Randevu Oluştur");
        } catch (Exception e) {
            clickByText("Yeni Randevu");
        }
        return this;
    }

    /** Doktor seçimi (select/combobox veya arama) */
    public AppointmentsPage chooseDoctor(String doctorName) {
        try {
            click(labelledSelect("Doktor"));
            click(optionByText(doctorName));
        } catch (Exception e) {
            // Bazı UI’larda doğrudan arama kutusu olabilir
            type(anyInputWithLabel("Doktor"), doctorName);
            click(optionByText(doctorName));
        }
        return this;
    }

    /** Hasta seçimi (select/combobox veya arama) */
    public AppointmentsPage choosePatient(String patientNameOrPhone) {
        try {
            click(labelledSelect("Hasta"));
            click(optionByText(patientNameOrPhone));
        } catch (Exception e) {
            type(anyInputWithLabel("Hasta"), patientNameOrPhone);
            click(optionByText(patientNameOrPhone));
        }
        return this;
    }

    /** Departman/Poliklinik (opsiyonel – UI’da varsa) */
    public AppointmentsPage chooseDepartment(String department) {
        try {
            click(labelledSelect("Departman"));
            click(optionByText(department));
        } catch (Exception ignored) {}
        return this;
    }

    /** Tarih & Saat alanları (UI’da datepicker/timepicker olabilir; ilk basit yaklaşım) */
    public AppointmentsPage setDateTime(AppointmentData data) {
        try { type(anyInputWithLabel("Tarih"), data.date()); } catch (Exception ignored) {}
        try { type(anyInputWithLabel("Saat"),  data.time()); } catch (Exception ignored) {}
        return this;
    }

    /** Not / açıklama (opsiyonel) */
    public AppointmentsPage setNote(String note) {
        try { type(textAreaWithLabel("Not"), note); } catch (Exception ignored) {}
        return this;
    }

    /** Kaydet ve temel doğrulama */
    public boolean saveAndVerify(AppointmentData data) {
        try {
            clickByText("Kaydet");
        } catch (Exception e) {
            clickByText("Oluştur");
        }

        // Başarı bildirimi / toast
        if (pageHasText("kaydedildi") || pageHasText("başarı") || pageHasText("oluşturuldu")) {
            return true;
        }

        // Alternatif: listede randevunun görünmesi
        return pageHasText(data.doctor()) || pageHasText(data.patient()) || pageHasText(data.time());
    }

    /* ================== DURUM GÜNCELLEME ================== */

    /** Liste/kalendardan ilgili randevuyu aç (metne göre esnek seçim) */
    public AppointmentsPage openAppointment(String doctor, String patient) {
        // satır veya kart metninde doktor + hasta geçiyorsa tıkla
        click(By.xpath(
                "//*[self::tr or self::div or self::li]" +
                        "[contains(normalize-space(),'" + doctor + "') and contains(normalize-space(),'" + patient + "')]"
        ));
        return this;
    }

    /** Randevuyu “Tamamlandı” yap */
    public boolean markCompleted() {
        try { clickByText("Durum"); } catch (Exception ignored) {}
        try {
            clickByText("Tamamlandı");
        } catch (Exception e) {
            click(optionByText("Tamamlandı"));
        }
        return pageHasText("Tamamlandı") || pageHasText("başarı");
    }

    /** Randevuyu “İptal” yap */
    public boolean markCancelled() {
        try { clickByText("Durum"); } catch (Exception ignored) {}
        try {
            clickByText("İptal");
        } catch (Exception e) {
            click(optionByText("İptal"));
        }
        return pageHasText("İptal") || pageHasText("başarı");
    }

    /** Randevuyu sil (onay dialog’unda “Evet/Sil/Tamam” tıkla) */
    public boolean deleteAppointment(String doctor, String patient) {
        try {
            clickByText("Sil");
        } catch (Exception e) {
            click(By.xpath("//button[contains(normalize-space(),'Sil')]"));
        }

        try { clickByText("Evet"); } catch (Exception ignored) {}
        try { clickByText("Onayla"); } catch (Exception ignored) {}
        try { clickByText("Tamam"); } catch (Exception ignored) {}

        // Silindikten sonra listede ilgili kayıt görünmemeli
        return !pageHasText(doctor + " " + patient);
    }

    /* ================== Yardımcı locator şablonları ================== */

    private By anyInputWithLabel(String label) {
        return By.xpath(
                "//*[self::label][contains(normalize-space(),'" + label + "')]/following::input[1] | " +
                        "//*[@placeholder][contains(@placeholder,'" + label + "')][1]"
        );
    }

    private By textAreaWithLabel(String label) {
        return By.xpath(
                "//*[self::label][contains(normalize-space(),'" + label + "')]/following::textarea[1] | " +
                        "//*[@placeholder][contains(@placeholder,'" + label + "')][1]"
        );
    }

    private By labelledSelect(String label) {
        return By.xpath(
                "//*[self::label][contains(normalize-space(),'" + label + "')]/following::*" +
                        "[(self::div or self::button or self::span) and (contains(@class,'select') or @role='combobox')][1]"
        );
    }

    private By optionByText(String text) {
        return By.xpath(
                "//*[self::div or self::li or self::span][contains(normalize-space(),'" + text + "')]"
        );
    }
}
