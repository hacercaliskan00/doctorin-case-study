package pages;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;

/** Hasta oluşturma verisi */
public record PatientData(String firstName, String lastName, String identityNo,
                          String phone, String email, String birthDate, String gender) {

    public String fullName() { return (firstName + " " + lastName).trim(); }

    /** Hızlı örnek veri üreticisi */
    public static PatientData sample() {
        Random r = new Random();
        String fn = "HacerTest" + (1000 + r.nextInt(9000));
        String ln = "Otomasyon";
        String tc = "1" + (1000000000L + Math.abs(r.nextLong()) % 8999999999L); // 11 haneli gibi
        String ph = "5" + (100000000L + Math.abs(r.nextLong()) % 899999999L);   // 10 hane
        String em = "test+" + System.currentTimeMillis() + "@example.com";
        String bd = LocalDate.of(1996, 5, 10).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
        String gn = "Kadın"; // UI’da “Kadın/Erkek/Diğer” vb. ne geçiyorsa ona göre

        return new PatientData(fn, ln, tc, ph, em, bd, gn);
    }
}
