package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/** Ortak bekleme/etkileşim yardımcıları */
public abstract class BasePage {
    protected final WebDriver driver;
    protected final WebDriverWait wait;

    protected BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait  = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    protected WebElement el(By by) {
        return wait.until(ExpectedConditions.presenceOfElementLocated(by));
    }

    protected WebElement visible(By by) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }

    protected void click(By by) {
        visible(by).click();
    }

    protected void type(By by, String text) {
        WebElement e = visible(by);
        try {
            e.click();
            e.clear();
        } catch (Exception ignored) { /* bazı inputlar clear desteklemeyebilir */ }
        e.sendKeys(text);
    }

    /** Ekranda görünen bir buton/bağlantıyı metnine göre tıkla (esnek) */
    protected void clickByText(String text) {
        By by = By.xpath(
                "//*[self::button or self::a or self::span or self::div]" +
                        "[normalize-space()='" + text + "' or contains(normalize-space(),'" + text + "')]"
        );
        click(by);
    }

    /** İçeriğinde metin geçen görünür elemanı döndürür */
    protected WebElement visibleByText(String text) {
        By by = By.xpath("//*[contains(normalize-space(),'" + text + "')]");
        return visible(by);
    }

    /** Growl/Snackbar/Toast gibi kısa bildirimleri yakalamak için */
    protected boolean pageHasText(String snippet) {
        try {
            By by = By.xpath("//*[contains(.,'" + snippet + "')]");
            visible(by);
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }
}
