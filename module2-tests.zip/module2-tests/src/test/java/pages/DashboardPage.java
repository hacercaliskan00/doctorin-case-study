package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Login sonrası ana alan – sol menü/üst bar eylemleri
 */
public class DashboardPage extends BasePage {

    public DashboardPage(WebDriver driver) {
        super(driver);
    }

    /** Sol menüden Randevular sayfasına geçiş */
    public AppointmentsPage goToAppointments() {
        // Menüde "Randevu" veya "Randevular" yazan öğeye tıkla
        try {
            click(By.xpath("//*[contains(@class,'menu') or contains(@class,'nav') or self::a or self::span][contains(text(),'Randevular')]"));
        } catch (Exception e) {
            click(By.xpath("//*[contains(@class,'menu') or contains(@class,'nav') or self::a or self::span][contains(text(),'Randevu')]"));
        }
        return new AppointmentsPage(driver);
    }

    /** Üstteki “Müşteri / değiştir” diyalogundan klinik seçimi */
    public DashboardPage selectTenant(String tenantName) {
        // “Müşteri” satırındaki “değiştir” butonuna bas
        clickByText("değiştir");

        // Açılan listede klinik adına tıkla
        click(By.xpath("//*[contains(@class,'option') or self::li or self::div]" +
                "[contains(normalize-space(),'" + tenantName + "')]"));

        // Onay/Seç/Tamam varyasyonlarını da dene
        try { clickByText("Seç"); } catch (Exception ignored) {}
        try { clickByText("Tamam"); } catch (Exception ignored) {}

        return this;
    }

    /** Sol menüden Doktorlar modülüne geçiş */
    public DoctorsPage goToDoctors() {
        click(By.xpath("//*[contains(@class,'menu') or contains(@class,'nav') or self::a or self::span]" +
                "[contains(.,'Doktor')]"));
        return new DoctorsPage(driver);
    }

    /** Sol menüden Hastalar modülüne geçiş */
    public PatientsPage goToPatients() {
        click(By.xpath("//*[contains(@class,'menu') or contains(@class,'nav') or self::a or self::span]" +
                "[contains(.,'Hasta')]"));
        return new PatientsPage(driver);
    }
}
