package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class PatientCreationTest extends BaseTest {

    @Test
    public void createPatient_success() {
        // 1) Login
        driver().get("https://testapp.doctorin.app");
        LoginPage login = new LoginPage(driver());
        login.loginAs("Test", "Test123.");

        // 2) Dashboard -> Tenant seç -> Hastalar modülü
        DashboardPage dashboard = new DashboardPage(driver());
        dashboard.selectTenant("Nişantaşı Klinik");

        // Menüde “Hasta / Hastalar” yazıyorsa:
        // Eğer DashboardPage’te goToPatients() yoksa, metne göre tıklayalım:
        // (İstersen DashboardPage'e goToPatients() metodu ekleriz)
        // dashboard.goToPatients();

        // Esnek: menüde metnine göre tıkla
        new BasePage(driver()) {}.clickByText("Hasta");
        new BasePage(driver()) {}.clickByText("Hastalar");

        PatientsPage patients = new PatientsPage(driver());
        PatientData data = PatientData.sample();

        patients
                .startNewPatient()
                .fillPatientForm(data);

        boolean ok = patients.saveAndVerify(data);
        Assert.assertTrue(ok, "Hasta kaydı başarıyla tamamlanamadı!");

        System.out.println("✅ Hasta oluşturma akışı başarıyla tamamlandı: " + data.fullName());
    }
}

