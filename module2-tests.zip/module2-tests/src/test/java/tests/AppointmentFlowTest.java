package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class AppointmentFlowTest extends BaseTest {

    @Test
    public void create_complete_cancel_delete_appointment() {
        // 1) Login
        driver().get("https://testapp.doctorin.app");
        LoginPage login = new LoginPage(driver());
        login.loginAs("Test", "Test123.");

        // 2) Dashboard -> Tenant seç -> Randevular
        DashboardPage dashboard = new DashboardPage(driver());
        dashboard
                .selectTenant("Nişantaşı Klinik")    // müşteri seç
                .goToAppointments();                 // menüden Randevular’a git

        AppointmentsPage appt = new AppointmentsPage(driver());

        // 3) Örnek veri (var olan doktor/hasta adlarını kullanın)
        AppointmentData data = AppointmentData.sample(
                "Dr. Ayşe Yılmaz",   // doktor
                "HacerTest",         // hasta
                "Dahiliye"           // departman (varsa)
        );

        // 4) Randevu oluştur
        appt.startNewAppointment()
                .chooseDoctor(data.doctor())
                .choosePatient(data.patient())
                .chooseDepartment(data.department())
                .setDateTime(data)
                .setNote(data.note());

        boolean created = appt.saveAndVerify(data);
        Assert.assertTrue(created, "Randevu oluşturulamadı!");

        // 5) Randevuyu aç → “Tamamlandı”
        appt.openAppointment(data.doctor(), data.patient());
        boolean completed = appt.markCompleted();
        Assert.assertTrue(completed, "Randevu 'Tamamlandı' yapılamadı!");

        // 6) İptal (bazı sistemlerde tamamlanandan iptale izin verilmeyebilir)
        boolean cancelled = appt.markCancelled();
        Assert.assertTrue(cancelled, "Randevu 'İptal' yapılamadı!");

        // 7) Sil
        boolean deleted = appt.deleteAppointment(data.doctor(), data.patient());
        Assert.assertTrue(deleted, "Randevu silinemedi!");

        System.out.println("✅ Randevu akışı başarıyla tamamlandı (oluştur → tamamla → iptal → sil).");
    }
}
