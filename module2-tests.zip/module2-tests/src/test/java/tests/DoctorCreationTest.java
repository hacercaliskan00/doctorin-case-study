package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class DoctorCreationTest extends BaseTest {

    @Test
    public void createDoctor_success() {
        // 1) Login
        driver().get("https://testapp.doctorin.app");
        LoginPage login = new LoginPage(driver());
        login.loginAs("Test", "Test123.");

        // 2) Dashboard -> Tenant seç -> Doktorlar
        DashboardPage dashboard = new DashboardPage(driver());
        dashboard
                .selectTenant("Nişantaşı Klinik")
                .goToDoctors()
                // 3) Yeni doktor
                .startNewDoctor()
                .fillDoctorForm(DoctorData.sample());

        // 4) Kaydet + doğrula
        DoctorsPage doctors = new DoctorsPage(driver());
        boolean ok = doctors.saveAndVerify();

        Assert.assertTrue(ok, "Doktor kaydı başarıyla tamamlanamadı!");
        System.out.println("✅ Doktor oluşturma akışı başarıyla tamamlandı.");
    }
}

