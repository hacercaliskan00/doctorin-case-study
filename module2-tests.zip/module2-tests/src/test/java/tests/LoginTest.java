package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;

/**
 * LoginTest
 * Docterin login akışını test eder.
 */
public class LoginTest extends BaseTest {

    @Test
    public void testLogin() {
        // Sayfayı aç
        driver().get("https://testapp.doctorin.app");

        // LoginPage nesnesi oluştur
        LoginPage loginPage = new LoginPage(driver());

        // Kullanıcı girişi yap
        loginPage.loginAs("Test", "Test123.");

        // Dashboard doğrulama
        boolean dashboardVisible = loginPage.isDashboardVisible();
        Assert.assertTrue(dashboardVisible, "Login başarısız: Dashboard görünmedi!");

        System.out.println("✅ Login başarılı şekilde çalıştı.");
    }
}
