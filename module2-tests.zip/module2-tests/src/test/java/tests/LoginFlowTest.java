package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;

public class LoginFlowTest extends BaseTest {

    @Test
    public void shouldLoginSuccessfully() {
        driver().get("https://testapp.doctorin.app");

        LoginPage login = new LoginPage(driver());
        login.loginAs("Test", "Test123.");

        // Temel doğrulama (görsel/element tabanlı)
        Assert.assertTrue(login.isDashboardVisible(),
                "Login sonrası beklenen panel görünmedi!");
    }
}
