package support;

public final class Config {
    private Config(){}

    public static final String BASE_URL = "https://testapp.doctorin.app";
    public static final String USERNAME = "Test";
    public static final String PASSWORD = "Test123";
}
